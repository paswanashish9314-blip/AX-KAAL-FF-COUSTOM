AX KAAL FF CUSTOM — Android Studio starter project

WHAT THIS IS
A starter Android app project with a dark red/black gaming-style interface:
- Tournament information placeholder
- Player name + Free Fire UID registration form (local demo only)
- Room ID/password placeholder
- Basic tournament rules

IMPORTANT LIMITATIONS
- This is source code, not a compiled APK.
- Registration is not uploaded or stored on a server.
- Room details are placeholders; no live admin dashboard/backend is connected.
- Do not put real passwords or sensitive information in this demo.
- This is an unofficial fan/community app concept and is not affiliated with Garena.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync finish; install Android SDK 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

To make a real multi-user tournament app, add a secure backend, admin authentication,
database, and server-side registration validation before publishing.
