package com.axkaal.ffcustom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF191919)
private val Red = Color(0xFFFF3434)
private val Muted = Color(0xFFBDBDBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppScreen() }
    }
}

@Composable
fun AppScreen() {
    var playerName by remember { mutableStateOf("") }
    var playerUid by remember { mutableStateOf("") }
    var registered by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Red,
        onBackground = Color.White, onSurface = Color.White
    )) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(Bg).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("AX KAAL", color = Red, fontSize = 15.sp, fontWeight = FontWeight.Black)
                Text("FF CUSTOM", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("CUSTOM ROOM • TOURNAMENT HUB", color = Muted, fontSize = 11.sp)
            }
            item { SectionCard("🔥  UPCOMING TOURNAMENT") {
                Text("Room match details will appear here.", color = Muted)
                Text("Date: To be announced", color = Color.White)
                Text("Time: To be announced", color = Color.White)
            } }
            item { SectionCard("📝  PLAYER REGISTRATION") {
                OutlinedTextField(value = playerName, onValueChange = { playerName = it },
                    label = { Text("Player name") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true)
                OutlinedTextField(value = playerUid, onValueChange = { playerUid = it },
                    label = { Text("Free Fire UID") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true)
                Button(
                    onClick = { registered = playerName.isNotBlank() && playerUid.isNotBlank() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text("REGISTER", fontWeight = FontWeight.Bold) }
                if (registered) Text("Registration saved on this screen.", color = Color(0xFF7CDB91))
                Text("Demo only: registration is not sent to a server.", color = Muted, fontSize = 11.sp)
            } }
            item { SectionCard("🔐  ROOM DETAILS") {
                Text("Room ID: Not published yet", color = Color.White)
                Text("Password: Not published yet", color = Color.White)
                Text("Room details will be added by the organizer.", color = Muted, fontSize = 11.sp)
            } }
            item { SectionCard("🏆  TOURNAMENT RULES") {
                Text("• Follow the organizer's match timing", color = Muted)
                Text("• Enter the correct player UID", color = Muted)
                Text("• Keep your team name appropriate", color = Muted)
            } }
            item {
                Text("Unofficial community app concept • Not affiliated with Garena or Free Fire.",
                    color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Red, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            content()
        }
    }
}
